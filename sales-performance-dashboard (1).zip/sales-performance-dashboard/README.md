# 📊 Sales Performance Dashboard

> **Tools:** Python (pandas) · SQL (SQLite) · Microsoft Excel · Data Cleaning · Data Visualisation
> **Type:** Data Analysis Portfolio Project — Google Data Analytics Certificate methodology
> **Author:** Ernestina Thembi Zah | [LinkedIn](https://linkedin.com/in/zahthembiernestina)

## 📌 Project Overview

A complete end-to-end data analysis project following the Google Data Analytics lifecycle:
**Ask → Prepare → Process → Analyse → Share → Act**

Analysed 2 years (2023-2024) of e-commerce sales data across 5 global regions to identify
revenue drivers, seasonal patterns, and customer retention opportunities.

## ❓ Business Questions Answered

1. Which regions and product categories generate the most revenue?
2. Are there seasonal patterns that should inform inventory and staffing?
3. Which sales channels perform best, and where?
4. What is the value of repeat customers vs one-time buyers?

## 🧹 Data Cleaning Summary

Started with 1,897 raw records → 1,850 clean records:

- Removed 47 exact duplicate rows
- Standardised 3 inconsistent date formats into ISO format
- Fixed inconsistent category text casing (18 variants → 6 clean categories)
- Standardised region naming (merged 'APAC', 'N. America' variants)
- Imputed 37 missing unit prices using category median
- Capped 5 extreme outlier values (data entry errors)
- Added calculated fields: revenue, order_month, order_quarter

## 💡 Key Findings

1. **North America & Europe** generate 58% of total revenue ($224K and $202K respectively)
2. **Electronics dominates** at 73% of revenue from only 29% of order volume — a concentration risk worth monitoring
3. **Strong Q4 seasonality** — November/December consistently outperform other months by 35-40%
4. **Retail Partner channel** has the highest average order value ($427) vs Online ($380)
5. **Repeat customers (90% of customer base) generate 97.4% of revenue** — $1,595 avg lifetime value vs $391 for one-time buyers — the single most actionable insight

## 📁 Repository Structure

| File | Description |
|---|---|
| `data/raw_sales_data.csv` | Original uncleaned dataset (1,897 rows) |
| `data/cleaned_sales_data.csv` | Cleaned dataset (1,850 rows) |
| `clean_data.py` | Python data cleaning script with documented steps |
| `sql/analysis_queries.sql` | 8 SQL business question queries |
| `sql/results/` | Query results as CSV |
| `dashboard/sales_dashboard.xlsx` | Interactive Excel dashboard — KPIs, pivot tables, charts |
| `report/insights_report.docx` | Full written case study with findings & recommendations |

## 📊 Dashboard Preview

The Excel dashboard includes:
- KPI summary cards (Total Revenue, Orders, AOV, Unique Customers)
- Revenue by Region (bar chart)
- Monthly Revenue Trend 2023-2024 (line chart)
- Revenue Share by Category (pie chart)
- Pivot tables: Region × Channel, Category Performance

## 🎯 Recommendations Delivered

1. Diversify beyond Electronics to reduce revenue concentration risk
2. Plan Q4 inventory/staffing 6-8 weeks ahead of the November spike
3. Prioritise customer retention programmes — the highest-ROI opportunity in the data
4. Investigate Middle East Marketplace's premium positioning as a template for other regions
5. Test bundling on Online channel to close the AOV gap with Retail Partner

## 🔗 Connect

**Ernestina Thembi Zah** · [LinkedIn](https://linkedin.com/in/zahthembiernestina) · tinathembizah@gmail.com
